from flask import Flask, request, render_template , redirect ,url_for

import time
import os
#declare a flask app
app = Flask(__name__, template_folder='templates', static_folder='static')

UPLOAD_PATH = "D:/Solvathon-23/UI/"
TEMPLATE_PATH="D:/Solvathon-23/UI/PPT_Templates"
OUTPUT_PATH = "D:/Solvathon-23/UI/PPT_Templates/Output_PPT"

def listOfQues():
    try:
        
        print("Getting ques ")
        quesList = ['This is request for proposal (RFP) of which company?',
                    'How much is customer Revenue?', 
                    'How much is deal TCV amount?', 
                    'How much is deal Tenure?', 
                    'What is the \'Purpose of RFP\'?', 
                    'What is decision date?',
                    'What is Q&A Clarification meeting date?',
                    'What is Submission of first proposal date?',
                    'What is this company all about? When was it found?',
                    'Do they have any Orchestrator tool?',
                    'What is the name of the orchestrator tool they have?',
                    'Count the number of subprocesses in scope?']
        return quesList
    except Exception as e:
        print("Error in list of ques",e)
        return []
    
def getBaseTemplate(tempPath):
    print("Fetching base templates ...")
    templates = os.listdir(tempPath)
    return templates
    
    
@app.route('/' ,methods =['GET','POST'])
def home():
   
    if request.method == 'POST':   
        f = request.files['file'] 
        print("Got file ",f.filename)
        f.save(os.path.join(UPLOAD_PATH,f.filename))   
        print("file saved" ,str(f.filename))
        quesList = listOfQues()
        baseTemplate= getBaseTemplate(TEMPLATE_PATH)
        return render_template("index.html", uploadStaus='True' , filename=str(f.filename),
                               quesList=quesList,baseTemplates=baseTemplate)
        
    return render_template("index.html",filename="",quesList=[])

@app.route('/genPPT',methods =['GET','POST'])
def genPPT():
    if request.method == 'POST':
        tempName = request.form.get("template")
        print(tempName)
        
        
# @app.route()
# def getQuestions():
#     ques list ans md(rfpdoc(path))
#     render tempalte ( list iterate n display)
    

# Running the app
if __name__ == '__main__':
    app.run(port=5001,debug = True)
