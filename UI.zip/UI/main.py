from flask import Flask, request, render_template , redirect ,url_for

import time

#declare a flask app
app = Flask(__name__, template_folder='templates', static_folder='static')


@app.route('/' ,methods =['GET','POST'])
def home():
     
    return render_template("index.html")

# @app.route('/aboutUs' ,methods =['GET','POST'])
# def aboutUs():        
      
#     return render_template("aboutUs.html")

# @app.route('/services' ,methods =['GET','POST'])
# def services():     
    
#     if request.method == "POST":
#         comment = request.form.get("comment")
#         return redirect(url_for('predict',cmt=comment))
   
#     return render_template("services.html")

# @app.route('/predict/<cmt>', methods=['GET','POST'])
# def predict(cmt):
#     comment = cmt 
#     explain=""
#     if request.method == "POST":
#         #comment2=cmt
#         comment2 = request.form.get("comment2")
#         print(comment2)
#         return redirect(url_for('explain',cmt2=comment2))
#         """ c_pkl = make_pipeline(vectorizer,model)
#         explainer = LimeTextExplainer(class_names=class_names)
#         exp_pkl = explainer.explain_instance(cmt2, c_pkl.predict_proba,num_features=10)
   
#         explain = exp_pkl.as_html()
#         print("EXP WORKED") """
        
#     else:
#         explain =""

#     pipeline = make_pipeline(vectorizer,model)
#     prediction = pipeline.predict([comment])
#     label = classdict.get(prediction[0])
   
#     return render_template("predict.html",comment=comment,predictxai=label , exp=explain)

# @app.route('/explain/<cmt2>',methods=["GET","POST"])
# def explain(cmt2):
#     if request.method == "POST":
#         return redirect(url_for('services'))
#     comment=cmt2
#     c_pkl = make_pipeline(vectorizer,model)
#     explainer = LimeTextExplainer(class_names=class_names)
#     exp_pkl = explainer.explain_instance(comment, c_pkl.predict_proba,num_features=10)
   
#     explain = exp_pkl.as_html()
#     return render_template("explain.html",comment=comment  , exp=explain)
# Running the app
if __name__ == '__main__':
    app.run(port=5001,debug = True)
